package org.bukkit.attribute;

/**
 * Something that carries {@link Attribute}s: every living entity.
 */
public interface Attributable {

    /**
     * Gets one of this object's attributes.
     *
     * @param attribute the attribute to get
     * @return the attribute instance, or {@code null} if this object does not carry it - a zombie
     *         has no jump strength, a horse no reinforcement chance
     */
    AttributeInstance getAttribute(Attribute attribute);
}
