package org.bukkit.attribute;

/**
 * The attributes a living entity carries in Minecraft 1.8.8.
 * <p>
 * BeltariaSpigot addition: the attribute API of Bukkit 1.9, cut down to what this version of the
 * game actually has. Values are read and written through {@link Attributable#getAttribute}.
 */
public enum Attribute {

    /** Maximum health of an entity, in half-hearts. */
    GENERIC_MAX_HEALTH("generic.maxHealth"),
    /** Range at which a mob notices and follows a target, in blocks. */
    GENERIC_FOLLOW_RANGE("generic.followRange"),
    /** Resistance to knockback, from 0 (none) to 1 (immune). */
    GENERIC_KNOCKBACK_RESISTANCE("generic.knockbackResistance"),
    /** Movement speed; a zombie walks at 0.23. */
    GENERIC_MOVEMENT_SPEED("generic.movementSpeed"),
    /** Melee damage dealt, in half-hearts. Only mobs that attack register it. */
    GENERIC_ATTACK_DAMAGE("generic.attackDamage"),
    /** Jump strength of a horse. Horses only. */
    HORSE_JUMP_STRENGTH("horse.jumpStrength"),
    /** Chance a zombie summons reinforcements when hurt. Zombies only. */
    ZOMBIE_SPAWN_REINFORCEMENTS("zombie.spawnReinforcements");

    private final String key;

    Attribute(String key) {
        this.key = key;
    }

    /**
     * Gets the name the game registers this attribute under, such as {@code generic.maxHealth}.
     *
     * @return the attribute's registry name
     */
    public String getKey() {
        return this.key;
    }
}
