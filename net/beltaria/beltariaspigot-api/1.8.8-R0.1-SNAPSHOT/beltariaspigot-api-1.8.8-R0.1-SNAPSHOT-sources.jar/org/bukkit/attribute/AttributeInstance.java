package org.bukkit.attribute;

import java.util.Collection;

/**
 * One attribute of one entity: a base value, the modifiers applied to it, and the resulting
 * value the game uses.
 * <p>
 * The value is clamped by the attribute's own range and, for max health, movement speed and
 * attack damage, by the caps set in {@code spigot.yml}: a base value above the cap is stored but
 * {@link #getValue()} stops at the cap.
 */
public interface AttributeInstance {

    /**
     * Gets the attribute this instance belongs to.
     *
     * @return the attribute
     */
    Attribute getAttribute();

    /**
     * Gets the base value, before any modifier.
     *
     * @return the base value
     */
    double getBaseValue();

    /**
     * Sets the base value.
     *
     * @param value the new base value
     */
    void setBaseValue(double value);

    /**
     * Gets every modifier applied to this instance.
     *
     * @return the modifiers, a copy
     */
    Collection<AttributeModifier> getModifiers();

    /**
     * Adds a modifier. A modifier with the same unique id must not already be applied.
     *
     * @param modifier the modifier to add
     * @throws IllegalArgumentException if a modifier with the same unique id is already applied
     */
    void addModifier(AttributeModifier modifier);

    /**
     * Removes a modifier, matched by its unique id.
     *
     * @param modifier the modifier to remove
     */
    void removeModifier(AttributeModifier modifier);

    /**
     * Gets the value the game uses: the base value with every modifier applied, clamped.
     *
     * @return the effective value
     */
    double getValue();

    /**
     * Gets the default base value of this attribute for any entity.
     *
     * @return the attribute's default
     */
    double getDefaultValue();
}
