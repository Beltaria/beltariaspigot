package org.bukkit.attribute;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang.Validate;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.util.NumberConversions;

/**
 * A change applied to an attribute's base value, identified by a unique id.
 * <p>
 * Modifiers stack in the order of their {@link Operation}: every {@link Operation#ADD_NUMBER}
 * first, then every {@link Operation#ADD_SCALAR} on the sum, then every
 * {@link Operation#MULTIPLY_SCALAR_1} on the result.
 */
public class AttributeModifier implements ConfigurationSerializable {

    private final UUID uuid;
    private final String name;
    private final double amount;
    private final Operation operation;

    public AttributeModifier(String name, double amount, Operation operation) {
        this(UUID.randomUUID(), name, amount, operation);
    }

    public AttributeModifier(UUID uuid, String name, double amount, Operation operation) {
        Validate.notNull(uuid, "uuid");
        Validate.notEmpty(name, "Name cannot be empty");
        Validate.notNull(operation, "operation");
        this.uuid = uuid;
        this.name = name;
        this.amount = amount;
        this.operation = operation;
    }

    /**
     * Gets the unique id of this modifier, what an instance matches on when removing it.
     *
     * @return the unique id
     */
    public UUID getUniqueId() {
        return this.uuid;
    }

    /**
     * Gets the name of this modifier, for people; the game does not read it.
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Gets the amount: a number to add, or a fraction to scale by, as the operation says.
     *
     * @return the amount
     */
    public double getAmount() {
        return this.amount;
    }

    /**
     * Gets how the amount combines with the value.
     *
     * @return the operation
     */
    public Operation getOperation() {
        return this.operation;
    }

    @Override
    public Map<String, Object> serialize() {
        Map<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("uuid", this.uuid.toString());
        data.put("name", this.name);
        data.put("operation", this.operation.name());
        data.put("amount", this.amount);
        return data;
    }

    public static AttributeModifier deserialize(Map<String, Object> args) {
        return new AttributeModifier(UUID.fromString((String) args.get("uuid")),
                (String) args.get("name"), NumberConversions.toDouble(args.get("amount")),
                Operation.valueOf((String) args.get("operation")));
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof AttributeModifier)) {
            return false;
        }
        AttributeModifier that = (AttributeModifier) other;
        return this.uuid.equals(that.uuid) && this.name.equals(that.name)
                && this.amount == that.amount && this.operation == that.operation;
    }

    @Override
    public int hashCode() {
        int result = this.uuid.hashCode();
        result = 31 * result + this.name.hashCode();
        result = 31 * result + Double.valueOf(this.amount).hashCode();
        result = 31 * result + this.operation.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "AttributeModifier{uuid=" + this.uuid + ", name=" + this.name + ", operation="
                + this.operation + ", amount=" + this.amount + "}";
    }

    /** How a modifier combines with the value; the order is the game's stacking order. */
    public enum Operation {
        /** Adds the amount to the base value. */
        ADD_NUMBER,
        /** Adds {@code amount} times the base value; several stack additively. */
        ADD_SCALAR,
        /** Multiplies the running value by {@code 1 + amount}; several stack multiplicatively. */
        MULTIPLY_SCALAR_1
    }
}
