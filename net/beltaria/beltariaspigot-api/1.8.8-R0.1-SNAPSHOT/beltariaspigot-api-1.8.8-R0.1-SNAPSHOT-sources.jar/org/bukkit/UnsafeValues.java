package org.bukkit;

import java.util.List;

import org.bukkit.inventory.ItemStack;

/**
 * This interface provides value conversions that may be specific to a
 * runtime, or have arbitrary meaning (read: magic values).
 * <p>
 * Their existence and behavior is not guaranteed across future versions. They
 * may be poorly named, throw exceptions, have misleading parameters, or any
 * other bad programming practice.
 * <p>
 * This interface is unsupported and only for internal use.
 *
 * @deprecated Unsupported {@literal &} internal use only
 */
@Deprecated
public interface UnsafeValues {

    Material getMaterialFromInternalName(String name);

    List<String> tabCompleteInternalMaterialName(String token, List<String> completions);

    ItemStack modifyItemStack(ItemStack stack, String arguments);

    Statistic getStatisticFromInternalName(String name);

    Achievement getAchievementFromInternalName(String name);

    List<String> tabCompleteInternalStatisticOrAchievementName(String token, List<String> completions);

    // PandaSpigot start
    byte[] serializeItem(ItemStack item);

    ItemStack deserializeItem(byte[] data);
    // PandaSpigot end

    // BeltariaSpigot start - expose the vanilla brew result
    /**
     * Computes the potion damage value vanilla brewing would produce for the
     * given bottle and ingredient, exactly as the brewing stand does - both the
     * ingredient's own transform and the stand's test for whether that mixture
     * is one it will brew at all.
     *
     * @param potionData the bottle's current damage value
     * @param ingredient the item in the brewing stand's ingredient slot
     * @return the resulting damage value, or {@code potionData} unchanged when
     *     the ingredient is null, is not a brewing reagent, or would produce a
     *     mixture the brewing stand refuses to start
     */
    int getBrewResult(int potionData, ItemStack ingredient);
    // BeltariaSpigot end
}
