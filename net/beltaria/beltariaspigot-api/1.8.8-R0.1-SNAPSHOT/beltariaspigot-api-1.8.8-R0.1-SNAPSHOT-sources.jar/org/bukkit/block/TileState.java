package org.bukkit.block;

import org.bukkit.persistence.PersistentDataHolder;

// BeltariaSpigot start - persistent data container API: tile entities are holders
/**
 * Represents a block state that also hosts a tile entity at its location. This
 * is the case for chests, signs, spawners and the like.
 * <p>
 * The persistent data container of a tile state is the tile entity's own, so
 * it is read and written live: values set through it are stored with the
 * block at once and survive the block's chunk being saved and loaded again.
 */
public interface TileState extends BlockState, PersistentDataHolder {
}
// BeltariaSpigot end
