package org.bukkit.block;

import org.bukkit.inventory.InventoryHolder;

/**
 * Represents a beacon.
 */
public interface Beacon extends TileState, InventoryHolder { // BeltariaSpigot - persistent data container API: a tile state
}
