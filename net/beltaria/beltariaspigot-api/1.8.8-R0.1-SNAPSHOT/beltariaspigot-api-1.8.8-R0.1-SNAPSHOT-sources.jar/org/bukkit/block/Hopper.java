package org.bukkit.block;

import org.bukkit.inventory.InventoryHolder;

/**
 * Represents a hopper.
 */
public interface Hopper extends TileState, InventoryHolder { // BeltariaSpigot - persistent data container API: a tile state

}
