package org.bukkit.block;

import org.bukkit.Material;
import org.bukkit.plugin.Plugin;

// BeltariaSpigot start - per-state dig rules
/**
 * The server-wide table of block states that are dug as if they were another block. Obtained
 * from {@link org.bukkit.Bukkit#getBlockDigRules()}.
 * <p>
 * A custom block usually borrows a vanilla state that looks right but digs wrong: a block
 * dressed as stone sitting on a log state is fast under an axe and slow under a pickaxe, which
 * is the opposite of what a player expects. Pointing that state at {@link Material#STONE} makes
 * the server time the dig as it would time stone - the right tool, its speed, its Efficiency and
 * Haste - without touching any other state of the same block. The five other log states, and
 * every log a player places, keep vanilla behaviour.
 * <p>
 * <strong>The block's hardness is not changed</strong>, only which tool is the right one and how
 * fast it goes. Nor is the drop: what a broken block yields is decided elsewhere, and a rule here
 * never makes a block drop something it would not have dropped.
 * <p>
 * <strong>The client is not told, and cannot be.</strong> It computes its own progress from its
 * own tables, which are per block and not per state, so the crack it draws still follows vanilla.
 * The server breaks the block when <em>its</em> clock says the dig is done: a state dug faster
 * than the client believes disappears while the crack is still filling. That is the visible cost
 * of this feature, and the reason it is opt-in per state.
 * <p>
 * Rules belong to the plugin that set them and are dropped when that plugin is disabled, the same
 * way its listeners are. All methods may be called from any thread; a rule takes effect for the
 * next dig started after it.
 */
public interface BlockDigRules {

    /**
     * Makes one block state dig as if it were another block.
     *
     * @param plugin the plugin the rule belongs to; must be enabled
     * @param block the material whose state is being ruled
     * @param data the data value of that state, 0 to 15
     * @param dugAs the block whose digging rules apply instead; its hardness is not borrowed
     * @throws IllegalArgumentException if an argument is {@code null}, if {@code data} is out of
     *     range, or if either material is not a block
     * @throws org.bukkit.plugin.IllegalPluginAccessException if the plugin is not enabled
     */
    public void setDugAs(Plugin plugin, Material block, byte data, Material dugAs);

    /**
     * Removes the rule on one block state, restoring vanilla digging.
     *
     * @param block the material whose state is being cleared
     * @param data the data value of that state, 0 to 15
     * @return {@code true} if a rule was in force
     * @throws IllegalArgumentException if {@code block} is {@code null} or is not a block
     */
    public boolean clear(Material block, byte data);

    /**
     * Gets the block whose digging rules apply to one state.
     *
     * @param block the material to read
     * @param data the data value of that state, 0 to 15
     * @return the stand-in block, or {@code null} when the state digs as itself
     * @throws IllegalArgumentException if {@code block} is {@code null} or is not a block
     */
    public Material getDugAs(Material block, byte data);

    /**
     * Removes every rule set by one plugin. Called for a plugin as it is disabled.
     *
     * @param plugin the plugin whose rules are dropped
     * @throws IllegalArgumentException if {@code plugin} is {@code null}
     */
    public void unregisterAll(Plugin plugin);
}
// BeltariaSpigot end
