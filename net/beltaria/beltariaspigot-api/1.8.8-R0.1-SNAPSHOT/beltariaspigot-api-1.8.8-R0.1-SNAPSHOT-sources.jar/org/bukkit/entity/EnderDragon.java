package org.bukkit.entity;

/**
 * Represents an Ender Dragon
 */
public interface EnderDragon extends ComplexLivingEntity {

    // BeltariaSpigot start - plugin-controlled dragon flight
    /**
     * Steers the dragon to a point. While a point is set the dragon never picks one itself:
     * vanilla flies it to a random point within 60 blocks of the world origin, or after a random
     * player of the whole world, which takes a dragon outside the End away from any arena.
     * <p>
     * The point is followed, not reached: the dragon keeps vanilla's flight - at most 50 degrees
     * of turn a tick, its climb and its speed - and circles a point it has reached. Move the point
     * to move the dragon. It is not saved with the entity, and must be called on the main thread.
     *
     * @param target the point, in the dragon's world (a location without a world is taken in
     *     it), or {@code null} to give the flight back to vanilla
     * @throws IllegalArgumentException if the point is in another world or not finite
     */
    public void setFlightTarget(org.bukkit.Location target);

    /**
     * Gets the point the dragon is steered to.
     *
     * @return a copy of the point, in the dragon's world, or {@code null} under vanilla flight
     */
    public org.bukkit.Location getFlightTarget();
    // BeltariaSpigot end
}
