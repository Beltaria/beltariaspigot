package org.bukkit.entity;

/**
 * Represents an ambient mob
 */
public interface Ambient extends Mob {} // BeltariaSpigot - Mob
