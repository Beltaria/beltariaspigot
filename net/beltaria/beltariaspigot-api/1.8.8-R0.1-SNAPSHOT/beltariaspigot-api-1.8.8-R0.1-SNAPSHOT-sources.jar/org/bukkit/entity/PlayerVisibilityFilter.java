package org.bukkit.entity;

// BeltariaSpigot start - player visibility filters
/**
 * Decides whether one player's client is sent another player's entity.
 * <p>
 * A player a filter hides is treated by the entity tracker exactly as if it were out of the
 * viewer's tracking range: it is destroyed on the viewer's client and spawned again through the
 * tracker's ordinary paths once every filter lets it through. Unlike
 * {@link Player#hidePlayer(Player)} it stays in the viewer's tab list, and it never touches the
 * hidden-player set that vanish plugins own - the two compose, a player is shown only when
 * neither hides it.
 * <p>
 * <b>Hot path.</b> Filters are called on the main thread for every (viewer, player) pair the
 * tracker re-evaluates, which is every time either of them moves far enough. They must be cheap
 * pure lookups of state the plugin keeps up to date elsewhere - no region queries, no permission
 * checks, no I/O. A filter that throws is removed and logged, and the players it hid are shown as
 * the tracker next re-evaluates them.
 * <p>
 * The answer must not change on its own: when the state a filter reads changes, the plugin calls
 * {@link Player#refreshVisibility()} for the players concerned, which re-runs the tracker's
 * decision for every pair involving them.
 *
 * @see org.bukkit.Server#addPlayerVisibilityFilter(org.bukkit.plugin.Plugin, PlayerVisibilityFilter)
 */
@FunctionalInterface
public interface PlayerVisibilityFilter {

    /**
     * @param viewer the player whose client would receive the entity
     * @param target the player that would be shown; never {@code viewer}
     * @return {@code false} to keep {@code target} off {@code viewer}'s client
     */
    boolean canSee(Player viewer, Player target);
}
// BeltariaSpigot end
