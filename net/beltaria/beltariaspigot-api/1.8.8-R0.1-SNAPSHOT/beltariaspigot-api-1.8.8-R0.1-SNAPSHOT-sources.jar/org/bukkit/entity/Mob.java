package org.bukkit.entity;

import com.destroystokyo.paper.entity.Pathfinder;
import org.bukkit.Location;

/**
 * A mob: a living entity with an artificial intelligence - goal selectors, a target, a navigator
 * and a look controller. Every creature, slime, flying, ambient and water mob is one; players and
 * armor stands are not.
 * <p>
 * BeltariaSpigot addition, shaped after the {@code Mob} of Bukkit 1.13 and the goal and
 * pathfinder API of Paper. The goals themselves are reached through
 * {@link org.bukkit.Bukkit#getMobGoals()}; whether the AI runs at all is
 * {@link LivingEntity#setAI}.
 */
public interface Mob extends LivingEntity {

    /**
     * Sets what this mob attacks. The mob's own targeting goals may replace it on their next
     * evaluation; strip them first for a target that holds.
     *
     * @param target the new target, or {@code null} to clear it
     */
    public void setTarget(LivingEntity target);

    /**
     * Gets what this mob attacks.
     *
     * @return the current target, or {@code null}
     */
    public LivingEntity getTarget();

    /**
     * Gets this mob's navigator.
     *
     * @return the pathfinder
     */
    public Pathfinder getPathfinder();

    /**
     * Turns this mob's head towards an entity, at its usual head speed.
     *
     * @param entity the entity to look at
     */
    public void lookAt(Entity entity);

    /**
     * Turns this mob's head towards an entity.
     *
     * @param entity the entity to look at
     * @param headRotationSpeed degrees of yaw the head may turn per tick
     * @param maxHeadPitch degrees of pitch the head may reach, up or down
     */
    public void lookAt(Entity entity, float headRotationSpeed, float maxHeadPitch);

    /**
     * Turns this mob's head towards a location, at its usual head speed.
     *
     * @param location the location to look at
     */
    public void lookAt(Location location);

    /**
     * Turns this mob's head towards a location.
     *
     * @param location the location to look at
     * @param headRotationSpeed degrees of yaw the head may turn per tick
     * @param maxHeadPitch degrees of pitch the head may reach, up or down
     */
    public void lookAt(Location location, float headRotationSpeed, float maxHeadPitch);

    /**
     * Turns this mob's head towards a point, at its usual head speed.
     *
     * @param x the point's x
     * @param y the point's y
     * @param z the point's z
     */
    public void lookAt(double x, double y, double z);

    /**
     * Turns this mob's head towards a point.
     *
     * @param x the point's x
     * @param y the point's y
     * @param z the point's z
     * @param headRotationSpeed degrees of yaw the head may turn per tick
     * @param maxHeadPitch degrees of pitch the head may reach, up or down
     */
    public void lookAt(double x, double y, double z, float headRotationSpeed, float maxHeadPitch);

    /**
     * Gets how many degrees of yaw this mob's head turns per tick when it looks at something.
     *
     * @return the head rotation speed
     */
    public int getHeadRotationSpeed();

    /**
     * Gets how many degrees of pitch this mob's head may reach when it looks at something.
     *
     * @return the maximum head pitch
     */
    public int getMaxHeadPitch();

    /**
     * Makes this mob strike an entity now, exactly as its own melee goal does: the game's attack of
     * this mob type runs, with everything it carries - the mob attack damage source (so an
     * {@link org.bukkit.event.entity.EntityDamageByEntityEvent} with this mob as damager), the
     * knockback, the Knockback and Fire Aspect of the held item, and the Thorns and other armour
     * enchantments of the target. Type-specific extras run too: an iron golem throws its target
     * upwards and plays its swing, a wither skeleton withers, a burning zombie sets fire. A mob type
     * with no melee attack of its own (a pig, a squid) does nothing and answers {@code false}.
     * <p>
     * Must be called from the main thread. Nothing happens, and {@code false} is answered, when the
     * target is this mob, either of them is dead, or they are in different worlds. No range or line
     * of sight is checked: the caller decides when a hit lands.
     *
     * @param target the entity to strike
     * @return {@code true} if the target took damage
     * @throws IllegalStateException if called off the main thread
     * @throws IllegalArgumentException if the target is null
     * @see #attackWithoutExtras(Entity, double)
     */
    public boolean attack(Entity target);

    /**
     * Makes this mob strike an entity now with the plain melee hit every hostile mob shares, and
     * none of its type's extras: the target takes {@code damage} (plus the held item's Sharpness,
     * Smite or Bane bonus) from the mob attack damage source, so an
     * {@link org.bukkit.event.entity.EntityDamageByEntityEvent} fires with this mob as damager; then
     * come the knockback, the held item's Knockback and Fire Aspect, and the target's Thorns. An iron
     * golem does not throw its target or play its swing, a wither skeleton does not wither.
     * <p>
     * This is the zombie's hit with its damage given, whatever the mob is: the damage does not come
     * from the mob's attack damage attribute, which an iron golem does not have.
     * <p>
     * Same conditions as {@link #attack(Entity)}: main thread only, and nothing happens for a target
     * that is this mob, dead, or in another world, or when this mob is dead.
     *
     * @param target the entity to strike
     * @param damage the base damage, finite and not negative
     * @return {@code true} if the target took damage
     * @throws IllegalStateException if called off the main thread
     * @throws IllegalArgumentException if the target is null or the damage is negative or not finite
     */
    public boolean attackWithoutExtras(Entity target, double damage);

    /**
     * Sets whether this mob counts toward the natural-spawning mob cap of its creature type
     * (monsters, animals, water and ambient mobs). A mob that does not count leaves its place to
     * the natural spawner: a plugin's own monsters no longer stop vanilla ones from spawning.
     * <p>
     * Every mob counts by default, as in vanilla. The setting is saved with the mob and survives a
     * chunk unload and reload; the counts are adjusted at once when it changes on a mob already in
     * the world. Must be called from the main thread.
     *
     * @param counts {@code false} to leave this mob out of the mob cap
     * @throws IllegalStateException if called off the main thread
     */
    public void setCountsTowardMobCap(boolean counts);

    /**
     * Gets whether this mob counts toward the natural-spawning mob cap of its creature type.
     *
     * @return {@code true} unless {@link #setCountsTowardMobCap(boolean)} left it out
     */
    public boolean countsTowardMobCap();
}
