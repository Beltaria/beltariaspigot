package org.bukkit.entity;

import com.destroystokyo.paper.entity.Pathfinder;
import org.bukkit.Location;

/**
 * A mob: a living entity with an artificial intelligence - goal selectors, a target, a navigator
 * and a look controller. Every creature, slime, flying, ambient and water mob is one; players and
 * armor stands are not.
 * <p>
 * BeltariaSpigot addition, shaped after the {@code Mob} of Bukkit 1.13 and the goal and
 * pathfinder API of Paper. The goals themselves are reached through
 * {@link org.bukkit.Bukkit#getMobGoals()}; whether the AI runs at all is
 * {@link LivingEntity#setAI}.
 */
public interface Mob extends LivingEntity {

    /**
     * Sets what this mob attacks. The mob's own targeting goals may replace it on their next
     * evaluation; strip them first for a target that holds.
     *
     * @param target the new target, or {@code null} to clear it
     */
    public void setTarget(LivingEntity target);

    /**
     * Gets what this mob attacks.
     *
     * @return the current target, or {@code null}
     */
    public LivingEntity getTarget();

    /**
     * Gets this mob's navigator.
     *
     * @return the pathfinder
     */
    public Pathfinder getPathfinder();

    /**
     * Turns this mob's head towards an entity, at its usual head speed.
     *
     * @param entity the entity to look at
     */
    public void lookAt(Entity entity);

    /**
     * Turns this mob's head towards an entity.
     *
     * @param entity the entity to look at
     * @param headRotationSpeed degrees of yaw the head may turn per tick
     * @param maxHeadPitch degrees of pitch the head may reach, up or down
     */
    public void lookAt(Entity entity, float headRotationSpeed, float maxHeadPitch);

    /**
     * Turns this mob's head towards a location, at its usual head speed.
     *
     * @param location the location to look at
     */
    public void lookAt(Location location);

    /**
     * Turns this mob's head towards a location.
     *
     * @param location the location to look at
     * @param headRotationSpeed degrees of yaw the head may turn per tick
     * @param maxHeadPitch degrees of pitch the head may reach, up or down
     */
    public void lookAt(Location location, float headRotationSpeed, float maxHeadPitch);

    /**
     * Turns this mob's head towards a point, at its usual head speed.
     *
     * @param x the point's x
     * @param y the point's y
     * @param z the point's z
     */
    public void lookAt(double x, double y, double z);

    /**
     * Turns this mob's head towards a point.
     *
     * @param x the point's x
     * @param y the point's y
     * @param z the point's z
     * @param headRotationSpeed degrees of yaw the head may turn per tick
     * @param maxHeadPitch degrees of pitch the head may reach, up or down
     */
    public void lookAt(double x, double y, double z, float headRotationSpeed, float maxHeadPitch);

    /**
     * Gets how many degrees of yaw this mob's head turns per tick when it looks at something.
     *
     * @return the head rotation speed
     */
    public int getHeadRotationSpeed();

    /**
     * Gets how many degrees of pitch this mob's head may reach when it looks at something.
     *
     * @return the maximum head pitch
     */
    public int getMaxHeadPitch();
}
