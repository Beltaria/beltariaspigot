package org.bukkit.entity;

import org.bukkit.Location;
import org.bukkit.EntityEffect;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.metadata.Metadatable;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.UUID;
import org.bukkit.command.CommandSender;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.persistence.PersistentDataHolder; // BeltariaSpigot - persistent data container API: entities are holders

/**
 * Represents a base entity in the world
 */
public interface Entity extends Metadatable, CommandSender, PersistentDataHolder { // BeltariaSpigot - persistent data container API: entities are holders

    /**
     * Gets the entity's current position
     *
     * @return a new copy of Location containing the position of this entity
     */
    public Location getLocation();

    /**
     * Stores the entity's current position in the provided Location object.
     * <p>
     * If the provided Location is null this method does nothing and returns
     * null.
     *
     * @param loc the location to copy into
     * @return The Location object provided or null
     */
    public Location getLocation(Location loc);

    /**
     * Sets this entity's velocity
     *
     * @param velocity New velocity to travel with
     */
    public void setVelocity(Vector velocity);

    /**
     * Gets this entity's current velocity
     *
     * @return Current travelling velocity of this entity
     */
    public Vector getVelocity();

    /**
     * Returns true if the entity is supported by a block. This value is a
     * state updated by the server and is not recalculated unless the entity
     * moves.
     *
     * @return True if entity is on ground.
     */
    public boolean isOnGround();

    /**
     * Gets the current world this entity resides in
     *
     * @return World
     */
    public World getWorld();

    /**
     * Teleports this entity to the given location. If this entity is riding a
     * vehicle, it will be dismounted prior to teleportation.
     *
     * @param location New location to teleport this entity to
     * @return <code>true</code> if the teleport was successful
     */
    public boolean teleport(Location location);

    /**
     * Teleports this entity to the given location. If this entity is riding a
     * vehicle, it will be dismounted prior to teleportation.
     *
     * @param location New location to teleport this entity to
     * @param cause The cause of this teleportation
     * @return <code>true</code> if the teleport was successful
     */
    public boolean teleport(Location location, TeleportCause cause);

    /**
     * Teleports this entity to the target Entity. If this entity is riding a
     * vehicle, it will be dismounted prior to teleportation.
     *
     * @param destination Entity to teleport this entity to
     * @return <code>true</code> if the teleport was successful
     */
    public boolean teleport(Entity destination);

    /**
     * Teleports this entity to the target Entity. If this entity is riding a
     * vehicle, it will be dismounted prior to teleportation.
     *
     * @param destination Entity to teleport this entity to
     * @param cause The cause of this teleportation
     * @return <code>true</code> if the teleport was successful
     */
    public boolean teleport(Entity destination, TeleportCause cause);

    /**
     * Returns a list of entities within a bounding box centered around this
     * entity
     *
     * @param x 1/2 the size of the box along x axis
     * @param y 1/2 the size of the box along y axis
     * @param z 1/2 the size of the box along z axis
     * @return {@code List<Entity>} List of entities nearby
     */
    public List<org.bukkit.entity.Entity> getNearbyEntities(double x, double y, double z);

    /**
     * Returns a unique id for this entity
     *
     * @return Entity id
     */
    public int getEntityId();

    /**
     * Returns the entity's current fire ticks (ticks before the entity stops
     * being on fire).
     *
     * @return int fireTicks
     */
    public int getFireTicks();

    /**
     * Returns the entity's maximum fire ticks.
     *
     * @return int maxFireTicks
     */
    public int getMaxFireTicks();

    /**
     * Sets the entity's current fire ticks (ticks before the entity stops
     * being on fire).
     *
     * @param ticks Current ticks remaining
     */
    public void setFireTicks(int ticks);

    /**
     * Mark the entity's removal.
     */
    public void remove();

    /**
     * Returns true if this entity has been marked for removal.
     *
     * @return True if it is dead.
     */
    public boolean isDead();

    /**
     * Returns false if the entity has died or been despawned for some other
     * reason.
     *
     * @return True if valid.
     */
    public boolean isValid();

    /**
     * Gets the {@link Server} that contains this Entity
     *
     * @return Server instance running this Entity
     */
    public Server getServer();

    /**
     * Gets the primary passenger of a vehicle. For vehicles that could have
     * multiple passengers, this will only return the primary passenger.
     *
     * @return an entity
     */
    public abstract Entity getPassenger();

    /**
     * Set the passenger of a vehicle.
     *
     * @param passenger The new passenger.
     * @return false if it could not be done for whatever reason
     */
    public abstract boolean setPassenger(Entity passenger);

    /**
     * Check if a vehicle has passengers.
     *
     * @return True if the vehicle has no passengers.
     */
    public abstract boolean isEmpty();

    /**
     * Eject any passenger.
     *
     * @return True if there was a passenger.
     */
    public abstract boolean eject();

    /**
     * Returns the distance this entity has fallen
     *
     * @return The distance.
     */
    public float getFallDistance();

    /**
     * Sets the fall distance for this entity
     *
     * @param distance The new distance.
     */
    public void setFallDistance(float distance);

    /**
     * Record the last {@link EntityDamageEvent} inflicted on this entity
     *
     * @param event a {@link EntityDamageEvent}
     */
    public void setLastDamageCause(EntityDamageEvent event);

    /**
     * Retrieve the last {@link EntityDamageEvent} inflicted on this entity.
     * This event may have been cancelled.
     *
     * @return the last known {@link EntityDamageEvent} or null if hitherto
     *     unharmed
     */
    public EntityDamageEvent getLastDamageCause();

    /**
     * Returns a unique and persistent id for this entity
     *
     * @return unique id
     */
    public UUID getUniqueId();

    /**
     * Gets the amount of ticks this entity has lived for.
     * <p>
     * This is the equivalent to "age" in entities.
     *
     * @return Age of entity
     */
    public int getTicksLived();

    /**
     * Sets the amount of ticks this entity has lived for.
     * <p>
     * This is the equivalent to "age" in entities. May not be less than one
     * tick.
     *
     * @param value Age of entity
     */
    public void setTicksLived(int value);

    /**
     * Performs the specified {@link EntityEffect} for this entity.
     * <p>
     * This will be viewable to all players near the entity.
     *
     * @param type Effect to play.
     */
    public void playEffect(EntityEffect type);

    /**
     * Get the type of the entity.
     *
     * @return The entity type.
     */
    public EntityType getType();

    /**
     * Returns whether this entity is inside a vehicle.
     *
     * @return True if the entity is in a vehicle.
     */
    public boolean isInsideVehicle();

    /**
     * Leave the current vehicle. If the entity is currently in a vehicle (and
     * is removed from it), true will be returned, otherwise false will be
     * returned.
     *
     * @return True if the entity was in a vehicle.
     */
    public boolean leaveVehicle();

    /**
     * Get the vehicle that this player is inside. If there is no vehicle,
     * null will be returned.
     *
     * @return The current vehicle.
     */
    public Entity getVehicle();

    /**
     * Sets a custom name on a mob. This name will be used in death messages
     * and can be sent to the client as a nameplate over the mob.
     * <p>
     * Setting the name to null or an empty string will clear it.
     * <p>
     * This value has no effect on players, they will always use their real
     * name.
     *
     * @param name the name to set
     */
    public void setCustomName(String name);

    /**
     * Gets the custom name on a mob. If there is no name this method will
     * return null.
     * <p>
     * This value has no effect on players, they will always use their real
     * name.
     *
     * @return name of the mob or null
     */
    public String getCustomName();


    // PandaSpigot start - Adventure
    /**
     * Gets the custom name on a mob. If there is no name this method will
     * return null.
     * <p>
     * This value has no effect on players, they will always use their real
     * name.
     *
     * @return name of the mob or null
     */
    default net.kyori.adventure.text.Component customName() {
        return net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserializeOrNull(getCustomName());
    }

    /**
     * Sets a custom name on a mob. This name will be used in death messages
     * and can be sent to the client as a nameplate over the mob.
     * <p>
     * Setting the name to null or an empty string will clear it.
     * <p>
     * This value has no effect on players, they will always use their real
     * name.
     *
     * @param customName the name to set
     */
    default void customName(net.kyori.adventure.text.Component customName) {
        setCustomName(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().serializeOrNull(customName));
    }
    // PandaSpigot end

    /**
     * Sets whether or not to display the mob's custom name client side. The
     * name will be displayed above the mob similarly to a player.
     * <p>
     * This value has no effect on players, they will always display their
     * name.
     *
     * @param flag custom name or not
     */
    public void setCustomNameVisible(boolean flag);

    /**
     * Gets whether or not the mob's custom name is displayed client side.
     * <p>
     * This value has no effect on players, they will always display their
     * name.
     *
     * @return if the custom name is displayed
     */
    public boolean isCustomNameVisible();

    // BeltariaSpigot start
    /**
     * Overrides how far away, in blocks, players can be and still track (see) this entity.
     * Smaller ranges mean fewer entities streamed to distant clients - useful for decorative
     * armor stands, item frames, dropped items and holograms.
     * <p>
     * The override is capped by the server's global tracking limit and takes effect within a
     * tick. Players already tracking the entity beyond a newly shrunk range stop seeing it on
     * their next movement update.
     *
     * @param blocks the tracking range in blocks, or {@code -1} to restore the per-type default
     */
    public void setTrackingRange(int blocks);

    /**
     * Gets the per-entity tracking range override.
     *
     * @return the override in blocks, or {@code -1} when the per-type default applies
     */
    public int getTrackingRange();

    // BeltariaSpigot start - entity tracked-by query
    /**
     * Whether the entity tracker has sent this entity to {@code viewer}'s client and it is still
     * there. This is the server's own record, after range, vanish
     * ({@link Player#hidePlayer(Player)}), the anti-wallhack occlusion and
     * {@link PlayerVisibilityFilter}s - so a plugin that draws something on this entity for a
     * client (a passenger sent as packets, say) shows it exactly where the entity is shown.
     * <p>
     * A player is never tracked by itself: {@code player.isTrackedBy(player)} is {@code false}.
     *
     * @param viewer the player whose client is asked about
     * @return {@code true} if {@code viewer}'s client holds this entity
     * @throws IllegalArgumentException if {@code viewer} is {@code null}
     * @throws IllegalStateException if not called on the main thread
     */
    public boolean isTrackedBy(Player viewer);
    // BeltariaSpigot end

    /**
     * Overrides this entity's bounding box - the box the server uses for projectile hits,
     * explosions, collisions and nearby-entity searches - whatever its type would give it.
     * The box stays centred on the entity's position and applies at once; the type's own
     * resizing (an armor stand switching to marker, a zombie growing up) is overridden for
     * as long as the override stands.
     * <p>
     * Clients are not told: a player's own click still lands on the box their client knows
     * for this entity type. Pick a base type whose box is close to the shape wanted.
     *
     * @param width the box's width, in blocks, on both horizontal axes; positive and finite
     * @param height the box's height, in blocks; positive and finite
     * @throws IllegalArgumentException if either dimension is not a positive finite number
     */
    public void setBoundingBoxSize(float width, float height);

    /**
     * Removes the bounding box override, restoring the size the entity had when it was set.
     */
    public void clearBoundingBoxSize();

    /**
     * Gets whether a bounding box override is in force on this entity.
     *
     * @return {@code true} while {@link #setBoundingBoxSize} stands
     */
    public boolean hasBoundingBoxOverride();

    /**
     * Sets whether this entity makes no sound: no hurt, no death, no ambient sound, no step.
     * Saved with the entity, as the {@code Silent} tag.
     *
     * @param silent {@code true} to silence the entity
     */
    public void setSilent(boolean silent);

    /**
     * Gets whether this entity makes no sound.
     *
     * @return {@code true} if it is silent
     */
    public boolean isSilent();

    /**
     * Gets whether this entity is written to the world's chunk data when the chunk holding it
     * is saved.
     * <p>
     * Every entity is persistent when it is created. An entity that is not persistent is simply
     * skipped when its chunk is written: it still lives, ticks and is seen by players for as
     * long as the server is up, and it is gone when the chunk is next loaded from disk.
     * <p>
     * This is not {@link LivingEntity#setRemoveWhenFarAway(boolean)}, which decides whether the
     * server despawns a mob that no player is near - that one is about the entity's life, this
     * one only about the file.
     * <p>
     * It has no effect on players, who are saved in their own file rather than with a chunk.
     *
     * @return {@code true} if this entity is saved with its chunk
     */
    public boolean isPersistent();

    /**
     * Sets whether this entity is written to the world's chunk data.
     * <p>
     * For a plugin that spawns entities it recreates itself - shop keepers, holograms, NPCs -
     * this is what keeps a copy of them from being left behind in the world: mark them
     * {@code false} at spawn, and no chunk save can ever put them on disk, whichever tick it
     * lands on. Without it the only way to keep an entity out of the file is to remove it
     * before the chunk is written, which is a race against when the server chooses to write.
     * <p>
     * The flag is runtime state and is not itself saved anywhere; an entity already written to
     * disk is not removed by clearing it - remove the entity for that.
     *
     * @param persistent {@code true} to save this entity with its chunk, {@code false} to skip it
     */
    public void setPersistent(boolean persistent);
    // BeltariaSpigot end

    // Spigot Start
    public class Spigot
    {

        /**
         * Returns whether this entity is invulnerable.
         *         
        * @return True if the entity is invulnerable.
         */
        public boolean isInvulnerable()
        {
            throw new UnsupportedOperationException( "Not supported yet." );
        }
    }

    Spigot spigot();
    // Spigot End
}
