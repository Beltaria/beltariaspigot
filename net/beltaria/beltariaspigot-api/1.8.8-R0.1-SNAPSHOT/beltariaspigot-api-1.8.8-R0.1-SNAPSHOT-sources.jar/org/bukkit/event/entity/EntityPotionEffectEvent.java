package org.bukkit.event.entity;

import org.apache.commons.lang.Validate;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

// BeltariaSpigot start - the 1.13 potion effect event, backported under its modern name so a
// plugin written for several versions finds it where it looks for it
/**
 * Called when a potion effect is added to, changed on, or removed from a living entity.
 *
 * <p>Only effects applied by the game or by a plugin fire it; effects read back from a saved
 * entity do not.
 *
 * <p>On 1.8 an effect arriving on top of one of the same type always goes through the vanilla
 * merge, which keeps the stronger of the two and re-applies the effect (re-applying absorption
 * refills it). {@link #isOverride()} therefore starts {@code true} for {@link Action#CHANGED};
 * set it to {@code false} to leave the existing effect untouched.
 */
public class EntityPotionEffectEvent extends EntityEvent implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private boolean cancel;
    private final PotionEffect oldEffect;
    private final PotionEffect newEffect;
    private final Cause cause;
    private final Action action;
    private boolean override;

    public EntityPotionEffectEvent(LivingEntity livingEntity, PotionEffect oldEffect, PotionEffect newEffect, Cause cause, Action action, boolean override) {
        super(livingEntity);
        Validate.notNull(cause, "cause");
        Validate.notNull(action, "action");
        Validate.isTrue(oldEffect != null || newEffect != null, "an old or a new effect is required");
        this.oldEffect = oldEffect;
        this.newEffect = newEffect;
        this.cause = cause;
        this.action = action;
        this.override = override;
    }

    /**
     * Gets the effect as it was before the change.
     *
     * @return the old effect, or null for {@link Action#ADDED}
     */
    public PotionEffect getOldEffect() {
        return oldEffect;
    }

    /**
     * Gets the effect being applied.
     *
     * @return the new effect, or null for {@link Action#REMOVED} and {@link Action#CLEARED}
     */
    public PotionEffect getNewEffect() {
        return newEffect;
    }

    /**
     * Gets what caused the change.
     *
     * @return the cause
     */
    public Cause getCause() {
        return cause;
    }

    /**
     * Gets what happens to the effect.
     *
     * @return the action
     */
    public Action getAction() {
        return action;
    }

    /**
     * Gets the type of the effect being changed.
     *
     * @return the modified effect type
     */
    public PotionEffectType getModifiedType() {
        return oldEffect == null ? newEffect.getType() : oldEffect.getType();
    }

    /**
     * Whether the new effect is merged into the existing one. Only meaningful for
     * {@link Action#CHANGED}.
     *
     * @return true if the vanilla merge runs
     */
    public boolean isOverride() {
        return override;
    }

    /**
     * Sets whether the new effect is merged into the existing one. Only meaningful for
     * {@link Action#CHANGED}.
     *
     * @param override false to leave the existing effect as it is
     */
    public void setOverride(boolean override) {
        this.override = override;
    }

    @Override
    public LivingEntity getEntity() {
        return (LivingEntity) entity;
    }

    @Override
    public boolean isCancelled() {
        return cancel;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancel = cancel;
    }

    @Override
    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

    /**
     * What happens to the effect.
     */
    public enum Action {

        /**
         * The entity did not have an effect of this type.
         */
        ADDED,
        /**
         * The entity already had an effect of this type and the new one is merged into it.
         */
        CHANGED,
        /**
         * The effect is removed together with every other one (milk, death, /effect clear).
         */
        CLEARED,
        /**
         * The effect is removed on its own.
         */
        REMOVED
    }

    /**
     * What caused the change. The modern constants are all present so a plugin compiled against
     * a newer API resolves them; the ones marked as unused on 1.8 are never fired here.
     */
    public enum Cause {

        /**
         * Unused on 1.8.
         */
        AREA_EFFECT_CLOUD,
        /**
         * Unused on 1.8.
         */
        ARROW,
        /**
         * An attack: cave spider, wither skeleton, wither skull, elder guardian, Bane of
         * Arthropods.
         */
        ATTACK,
        /**
         * Unused on 1.8.
         */
        AXOLOTL,
        /**
         * A beacon.
         */
        BEACON,
        /**
         * The /effect command.
         */
        COMMAND,
        /**
         * Unused on 1.8.
         */
        CONDUIT,
        /**
         * A zombie villager being cured, and the villager it becomes.
         */
        CONVERSION,
        /**
         * A player's effects being cleared on respawn.
         */
        DEATH,
        /**
         * Unused on 1.8.
         */
        DOLPHIN,
        /**
         * The effect ran out.
         */
        EXPIRATION,
        /**
         * Eating food: golden apples, pufferfish, raw chicken, rotten flesh, spider eyes.
         */
        FOOD,
        /**
         * Unused on 1.8.
         */
        ILLUSION,
        /**
         * Unused on 1.8.
         */
        ITEM,
        /**
         * Drinking milk.
         */
        MILK,
        /**
         * Unused on 1.8.
         */
        PATROL_CAPTAIN,
        /**
         * A plugin.
         */
        PLUGIN,
        /**
         * Drinking a potion (a player, or a witch).
         */
        POTION_DRINK,
        /**
         * A splash potion.
         */
        POTION_SPLASH,
        /**
         * A spider spawning with an effect on hard difficulty.
         */
        SPIDER_SPAWN,
        /**
         * Unused on 1.8.
         */
        TOTEM,
        /**
         * Unused on 1.8.
         */
        TURTLE_HELMET,
        /**
         * Anything else, including NMS code that does not name a cause.
         */
        UNKNOWN,
        /**
         * A villager rewarded for a trade.
         */
        VILLAGER_TRADE,
        /**
         * Unused on 1.8.
         */
        WARDEN,
        /**
         * Unused on 1.8.
         */
        WITHER_ROSE
    }
}
// BeltariaSpigot end
