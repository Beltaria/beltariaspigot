package org.bukkit.event.player;

import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;

/**
 * Called when a player leaves a server
 */
public class PlayerQuitEvent extends PlayerEvent {
    private static final HandlerList handlers = new HandlerList();
    private net.kyori.adventure.text.Component quitMessage; // PandaSpigot - Adventure

    public PlayerQuitEvent(final Player who, final String quitMessage) {
    // PandaSpigot start - Adventure
        super(who);
        this.quitMessage = net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize(quitMessage);
    }

    public PlayerQuitEvent(final Player who, final net.kyori.adventure.text.Component quitMessage) {
    // PandaSpigot end
        super(who);
        this.quitMessage = quitMessage;
    }

    /**
     * Gets the quit message to send to all online players
     *
     * @return string quit message
     */
    public String getQuitMessage() {
        return net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().serializeOrNull(quitMessage); // PandaSpigot - Adventure
    }

    /**
     * Sets the quit message to send to all online players
     *
     * @param quitMessage quit message
     */
    public void setQuitMessage(String quitMessage) {
    // PandaSpigot start - Adventure
        this.quitMessage = net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserializeOrNull(quitMessage);
    }

    /**
     * Gets the quit message to send to all online players
     *
     * @return string quit message
     */
    public net.kyori.adventure.text.Component quitMessage() {
        return quitMessage;
    }

    /**
     * Sets the quit message to send to all online players
     *
     * @param quitMessage quit message
     */
    public void quitMessage(net.kyori.adventure.text.Component quitMessage) {
    // PandaSpigot end
        this.quitMessage = quitMessage;
    }

    @Override
    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }
}
