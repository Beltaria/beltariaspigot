package org.bukkit.event.player;

import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;

/**
 * Called when the locale of the player is changed.
 */
public class PlayerLocaleChangeEvent extends PlayerEvent {
    private static final HandlerList handlers = new HandlerList();
    private final String oldLocale;
    private final String newLocale;
    private final java.util.Locale adventure$oldLocale, adventure$newLocale; // PandaSpigot - Adventure

    public PlayerLocaleChangeEvent(final Player player, final String oldLocale, final String newLocale) {
        super(player);
        this.oldLocale = oldLocale;
        this.newLocale = newLocale;
        // PandaSpigot start - Adventure
        this.adventure$oldLocale = oldLocale == null ? java.util.Locale.US : net.kyori.adventure.translation.Translator.parseLocale(oldLocale);
        this.adventure$newLocale = newLocale == null ? java.util.Locale.US : net.kyori.adventure.translation.Translator.parseLocale(newLocale);
        // PandaSpigot end
    }

    /**
     * Gets the locale the player switched from.
     *
     * @return player's old locale
     */
    public String getOldLocale() {
        return oldLocale;
    }

    /**
     * Gets the locale the player is changed to.
     *
     * @return player's new locale
     */
    public String getNewLocale() {
        return newLocale;
    }

    // PandaSpigot start - Adventure
    /**
     * Gets the locale the player switched from.
     *
     * @return player's old locale
     */
    public java.util.Locale oldLocale() {
        return adventure$oldLocale;
    }

    /**
     * Gets the locale the player is changed to.
     *
     * @return player's new locale
     */
    public java.util.Locale newLocale() {
        return adventure$newLocale;
    }
    // PandaSpigot end

    @Override
    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }
}