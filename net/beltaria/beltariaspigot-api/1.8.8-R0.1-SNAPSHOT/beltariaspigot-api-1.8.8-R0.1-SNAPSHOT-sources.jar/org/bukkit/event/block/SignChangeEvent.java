package org.bukkit.event.block;

import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;

/**
 * Called when a sign is changed by a player.
 * <p>
 * If a Sign Change event is cancelled, the sign will not be changed.
 */
public class SignChangeEvent extends BlockEvent implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private boolean cancel = false;
    private final Player player;
    private final net.kyori.adventure.text.Component[] lines; // PandaSpigot - Adventure

    public SignChangeEvent(final Block theBlock, final Player thePlayer, final String[] theLines) {
    // PandaSpigot start - Adventure
        super(theBlock);
        this.player = thePlayer;
        this.lines = new net.kyori.adventure.text.Component[theLines.length];
        for (int i = 0; i < theLines.length; i++) {
            this.lines[i] = net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize(theLines[i]);
        }
    }

    public SignChangeEvent(final Block theBlock, final Player thePlayer, final net.kyori.adventure.text.Component[] theLines) {
    // PandaSpigot end
        super(theBlock);
        this.player = thePlayer;
        this.lines = theLines;
    }

    /**
     * Gets the player changing the sign involved in this event.
     *
     * @return the Player involved in this event
     */
    public Player getPlayer() {
        return player;
    }

    /**
     * Gets all of the lines of text from the sign involved in this event.
     *
     * @return the String array for the sign's lines new text
     */
    public String[] getLines() {
        return java.util.Arrays.stream(lines).map(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection()::serialize).toArray(String[]::new); // PandaSpigot - Adventure
    }

    /**
     * Gets a single line of text from the sign involved in this event.
     *
     * @param index index of the line to get
     * @return the String containing the line of text associated with the
     *     provided index
     * @throws IndexOutOfBoundsException thrown when the provided index is {@literal > 3
     *     or < 0}
     */
    public String getLine(int index) throws IndexOutOfBoundsException {
        return net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().serialize(lines[index]); // PandaSpigot - Adventure
    }

    /**
     * Sets a single line for the sign involved in this event
     *
     * @param index index of the line to set
     * @param line text to set
     * @throws IndexOutOfBoundsException thrown when the provided index is {@literal > 3
     *     or < 0}
     */
    public void setLine(int index, String line) throws IndexOutOfBoundsException {
    // PandaSpigot start - Adventure
        lines[index] = net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize(line);
    }

    /**
     * Gets all the lines of text from the sign involved in this event.
     *
     * @return the Component list for the sign's lines new text
     */
    public java.util.List<net.kyori.adventure.text.Component> lines() {
        return java.util.Arrays.asList(lines);
    }

    /**
     * Gets a single line of text from the sign involved in this event.
     *
     * @param index index of the line to get
     * @return the Component containing the line of text associated with the
     *     provided index
     * @throws IndexOutOfBoundsException thrown when the provided index is {@literal > 3
     *     or < 0}
     */
    public net.kyori.adventure.text.Component line(int index) throws IndexOutOfBoundsException {
        return lines[index];
    }

    /**
     * Sets a single line for the sign involved in this event
     *
     * @param index index of the line to set
     * @param line text to set
     * @throws IndexOutOfBoundsException thrown when the provided index is {@literal > 3
     *     or < 0}
     */
    public void line(int index, net.kyori.adventure.text.Component line) throws IndexOutOfBoundsException {
    // PandaSpigot end
        lines[index] = line;
    }

    public boolean isCancelled() {
        return cancel;
    }

    public void setCancelled(boolean cancel) {
        this.cancel = cancel;
    }

    @Override
    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }
}
