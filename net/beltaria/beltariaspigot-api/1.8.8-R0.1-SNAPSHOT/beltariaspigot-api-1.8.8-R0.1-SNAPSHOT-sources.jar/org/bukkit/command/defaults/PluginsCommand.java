package org.bukkit.command.defaults;

import java.util.ArrayList; // BeltariaSpigot
import java.util.Arrays;
import java.util.Collections; // BeltariaSpigot
import java.util.List; // BeltariaSpigot

import org.apache.commons.lang.StringUtils; // BeltariaSpigot
import net.md_5.bungee.api.chat.BaseComponent; // BeltariaSpigot
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player; // BeltariaSpigot
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager; // BeltariaSpigot
import org.bukkit.plugin.PluginProblems; // BeltariaSpigot
import org.bukkit.plugin.SimplePluginManager; // BeltariaSpigot

public class PluginsCommand extends BukkitCommand {
    public PluginsCommand(String name) {
        super(name);
        this.description = "Gets a list of plugins running on the server";
        this.usageMessage = "/plugins [plugin]"; // BeltariaSpigot - was "/plugins"
        this.setPermission("bukkit.command.plugins");
        this.setAliases(Arrays.asList("pl"));
    }

    @Override
    public boolean execute(CommandSender sender, String currentAlias, String[] args) {
        if (!testPermission(sender)) return true;

        // BeltariaSpigot start - sorted, failed jars listed, hover and click for players, /plugins <name> for details
        PluginListView view = view();
        if (args.length > 0) {
            for (String line : view.detailLines(StringUtils.join(args, ' '))) {
                sender.sendMessage(line);
            }
        } else if (sender instanceof Player) {
            for (BaseComponent[] line : view.summaryComponents(currentAlias)) {
                ((Player) sender).sendMessage(line);
            }
        } else {
            for (String line : view.summaryLines()) {
                sender.sendMessage(line);
            }
        }
        // BeltariaSpigot end
        return true;
    }

    // BeltariaSpigot start
    private static PluginListView view() {
        PluginManager manager = Bukkit.getPluginManager();
        PluginProblems problems = manager instanceof SimplePluginManager ? ((SimplePluginManager) manager).getPluginProblems() : null;
        List<PluginListView.Entry> entries = new ArrayList<PluginListView.Entry>();
        for (Plugin plugin : manager.getPlugins()) {
            entries.add(PluginListView.Entry.of(plugin, problems));
        }
        return new PluginListView(entries, problems == null ? Collections.<PluginProblems.LoadFailure>emptyList() : problems.getLoadFailures());
    }
    // BeltariaSpigot end

    // Spigot Start
    @Override
    public java.util.List<String> tabComplete(CommandSender sender, String alias, String[] args) throws IllegalArgumentException
    {
        // BeltariaSpigot start - complete plugin names for /plugins <name>; still nothing (not player names) otherwise
        if (args.length == 1 && testPermissionSilent(sender)) {
            return view().complete(args[0]);
        }
        // BeltariaSpigot end
        return java.util.Collections.emptyList();
    }
    // Spigot End
}
