package org.bukkit.command.defaults;

import java.util.Arrays;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class ReloadCommand extends BukkitCommand {
    // BeltariaSpigot start - the command stays registered, but only to explain itself
    private static final String[] EXPLANATION = new String[] {
        ChatColor.RED + "" + ChatColor.BOLD + "/reload is disabled on this server.",
        ChatColor.RED + "It does not restart anything: it disables every plugin and loads a second",
        ChatColor.RED + "copy of them inside the same running server, then hopes the first copy is",
        ChatColor.RED + "gone. It never is.",
        ChatColor.GRAY + " - Tasks, threads, listeners and database connections opened by the old copy",
        ChatColor.GRAY + "   keep running against worlds, entities and players that no longer exist.",
        ChatColor.GRAY + " - The old plugin classes are leaked every time, so memory use only grows.",
        ChatColor.GRAY + " - Plugins that read the world or other plugins on startup silently reload in",
        ChatColor.GRAY + "   the wrong order and end up holding stale data.",
        ChatColor.RED + "The damage shows up minutes or hours later - lost player data, duplicated",
        ChatColor.RED + "items, ghost entities, errors pointing at code that is no longer loaded -",
        ChatColor.RED + "and it looks like a bug in whichever plugin was unlucky, not like the reload.",
        ChatColor.GREEN + "Restart the server with /stop instead, or use the plugin's own reload command",
        ChatColor.GREEN + "if it has one - those only re-read config files, which is safe."
    };
    // BeltariaSpigot end

    public ReloadCommand(String name) {
        super(name);
        this.description = "Explains why reloading the server is not supported"; // BeltariaSpigot - was "Reloads the server configuration and plugins"
        this.usageMessage = "/reload";
        this.setPermission("bukkit.command.reload");
        this.setAliases(Arrays.asList("rl"));
    }

    @Override
    public boolean execute(CommandSender sender, String currentAlias, String[] args) {
        if (!testPermission(sender)) return true;

        // BeltariaSpigot start - explain why reloading is gone rather than reloading
        for (String line : EXPLANATION) {
            sender.sendMessage(line);
        }
        // BeltariaSpigot end

        return true;
    }

    // Spigot Start
    @Override
    public java.util.List<String> tabComplete(CommandSender sender, String alias, String[] args) throws IllegalArgumentException
    {
        return java.util.Collections.emptyList();
    }
    // Spigot End
}
