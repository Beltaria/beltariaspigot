package org.bukkit.command.defaults;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.ChatColor;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.PluginProblems;
import org.bukkit.plugin.PluginProblems.LoadFailure;

/**
 * What /plugins prints, built from a snapshot of the plugins so it can be
 * tested without a server: the summary (enabled plugins first, then the
 * disabled ones, then the jars that never loaded, each group alphabetical),
 * the hover and click shown to players, and the detail page of one plugin.
 */
final class PluginListView {
    static final int MAX_COMMANDS = 30;
    /** A 1.8 chat packet's string is at most 32767 bytes; this leaves room for the message's own wrapper. */
    static final int MAX_MESSAGE_JSON_BYTES = 30000;
    private static final int MAX_SUGGESTIONS = 5;

    private static final Comparator<Entry> ENABLED_FIRST = new Comparator<Entry>() {
        @Override
        public int compare(Entry a, Entry b) {
            if (a.enabled != b.enabled) {
                return a.enabled ? -1 : 1;
            }
            return String.CASE_INSENSITIVE_ORDER.compare(a.name, b.name);
        }
    };
    private static final Comparator<LoadFailure> BY_DISPLAY_NAME = new Comparator<LoadFailure>() {
        @Override
        public int compare(LoadFailure a, LoadFailure b) {
            return String.CASE_INSENSITIVE_ORDER.compare(a.getDisplayName(), b.getDisplayName());
        }
    };

    private final List<Entry> plugins;
    private final List<LoadFailure> failures;

    PluginListView(Collection<Entry> plugins, Collection<LoadFailure> failures) {
        List<Entry> sortedPlugins = new ArrayList<Entry>(plugins);
        Collections.sort(sortedPlugins, ENABLED_FIRST);
        this.plugins = Collections.unmodifiableList(sortedPlugins);
        List<LoadFailure> sortedFailures = new ArrayList<LoadFailure>(failures);
        Collections.sort(sortedFailures, BY_DISPLAY_NAME);
        this.failures = Collections.unmodifiableList(sortedFailures);
    }

    List<Entry> getPlugins() {
        return plugins;
    }

    List<LoadFailure> getFailures() {
        return failures;
    }

    /**
     * The summary as plain coloured text, for the console. The first line
     * keeps Bukkit's "Plugins (N): a, b" shape for whatever parses it.
     */
    List<String> summaryLines() {
        List<String> lines = new ArrayList<String>();
        StringBuilder line = new StringBuilder("Plugins (").append(plugins.size()).append("): ");
        for (int i = 0; i < plugins.size(); i++) {
            Entry plugin = plugins.get(i);
            if (i > 0) {
                line.append(ChatColor.WHITE).append(", ");
            }
            line.append(plugin.enabled ? ChatColor.GREEN : ChatColor.RED).append(plugin.name);
        }
        lines.add(line.toString());
        if (!failures.isEmpty()) {
            line = new StringBuilder().append(ChatColor.RED).append("Failed to load (").append(failures.size()).append("): ");
            for (int i = 0; i < failures.size(); i++) {
                LoadFailure failure = failures.get(i);
                if (i > 0) {
                    line.append(ChatColor.WHITE).append(", ");
                }
                line.append(ChatColor.DARK_RED).append(failure.getDisplayName())
                    .append(ChatColor.GRAY).append(" (").append(failure.getReason()).append(')');
            }
            lines.add(line.toString());
        }
        return lines;
    }

    /**
     * The summary for a player: the same lines, where hovering a name shows
     * the plugin and clicking it runs "/alias name". The hovers make the JSON
     * large - 47 plugins came to 37 KB - and a 1.8 chat packet holds at most
     * 32767 bytes, beyond which the server cannot encode it and drops the
     * player; so each line is cut into as many chat messages as it needs.
     */
    List<BaseComponent[]> summaryComponents(String alias) {
        List<BaseComponent[]> messages = new ArrayList<BaseComponent[]>();
        MessageSplitter line = new MessageSplitter(messages);
        line.add(new TextComponent("Plugins (" + plugins.size() + "): "));
        for (int i = 0; i < plugins.size(); i++) {
            Entry plugin = plugins.get(i);
            line.addItem(i > 0, clickable(plugin.name, plugin.enabled ? net.md_5.bungee.api.ChatColor.GREEN : net.md_5.bungee.api.ChatColor.RED,
                hoverText(plugin), alias));
        }
        line.finish();
        if (!failures.isEmpty()) {
            TextComponent prefix = new TextComponent("Failed to load (" + failures.size() + "): ");
            prefix.setColor(net.md_5.bungee.api.ChatColor.RED);
            line.add(prefix);
            for (int i = 0; i < failures.size(); i++) {
                LoadFailure failure = failures.get(i);
                line.addItem(i > 0, clickable(failure.getDisplayName(), net.md_5.bungee.api.ChatColor.DARK_RED, hoverText(failure), alias));
            }
            line.finish();
        }
        return messages;
    }

    /**
     * Fills chat messages up to a JSON size budget, starting a new message
     * when the next item would not fit. A separator stays at the end of the
     * message before the cut, so the messages read as the console line does.
     */
    private static final class MessageSplitter {
        private final List<BaseComponent[]> messages;
        private final List<BaseComponent> current = new ArrayList<BaseComponent>();
        private int size;

        MessageSplitter(List<BaseComponent[]> messages) {
            this.messages = messages;
        }

        void add(BaseComponent part) {
            int partSize = jsonSize(part);
            if (partSize > MAX_MESSAGE_JSON_BYTES) {
                // one hover alone too big for a chat packet: keep the name and the click
                part.setHoverEvent(null);
                partSize = jsonSize(part);
            }
            if (!current.isEmpty() && size + partSize > MAX_MESSAGE_JSON_BYTES) {
                finish();
            }
            current.add(part);
            size += partSize;
        }

        void addItem(boolean separated, BaseComponent item) {
            if (separated) {
                // the separator is tiny and the budget keeps room for it, so it never forces a cut itself
                current.add(separator());
                size += jsonSize(separator());
            }
            add(item);
        }

        void finish() {
            if (!current.isEmpty()) {
                messages.add(current.toArray(new BaseComponent[current.size()]));
                current.clear();
                size = 0;
            }
        }

        private static int jsonSize(BaseComponent part) {
            // +1 for the comma between the parts of the message's "extra" array
            return net.md_5.bungee.chat.ComponentSerializer.toString(part).getBytes(java.nio.charset.StandardCharsets.UTF_8).length + 1;
        }
    }

    /*
     * Hover text. A 1.8 tooltip never wraps, so a long line runs off the screen: every line is cut at
     * HOVER_WIDTH visible characters. And no bold: the 1.8 chat library reads a reset code as plain
     * white, so bold set on a title ran on through the whole tooltip.
     */
    String hoverText(Entry plugin) {
        List<String> lines = new ArrayList<String>();
        lines.add((plugin.enabled ? ChatColor.GREEN : ChatColor.RED) + plugin.name + ChatColor.GRAY + " v" + plugin.version);
        if (!plugin.enabled) {
            lines.add(ChatColor.RED + "Disabled" + (plugin.enableFailure != null ? ": " + plugin.enableFailure : ""));
        }
        if (plugin.description != null) {
            lines.add(ChatColor.WHITE + plugin.description);
        }
        if (!plugin.authors.isEmpty()) {
            lines.add(ChatColor.GRAY + "Authors: " + ChatColor.WHITE + join(plugin.authors));
        }
        if (!plugin.depend.isEmpty()) {
            lines.add(ChatColor.GRAY + "Depends: " + dependencies(plugin.depend));
        }
        if (!plugin.softDepend.isEmpty()) {
            lines.add(ChatColor.GRAY + "Soft depends: " + dependencies(plugin.softDepend));
        }
        lines.add(ChatColor.DARK_GRAY + "Click for details");
        return wrapLines(lines);
    }

    String hoverText(LoadFailure failure) {
        List<String> lines = new ArrayList<String>();
        lines.add(ChatColor.DARK_RED + failure.getDisplayName() + ChatColor.GRAY + " (" + failure.getFileName() + ")");
        lines.add(ChatColor.RED + "Failed to load: " + failure.getReason());
        lines.add(ChatColor.DARK_GRAY + "Click for details");
        return wrapLines(lines);
    }

    static final int HOVER_WIDTH = 40;

    private static String wrapLines(List<String> lines) {
        StringBuilder text = new StringBuilder();
        for (String line : lines) {
            for (String wrapped : wrap(line, HOVER_WIDTH)) {
                if (text.length() > 0) {
                    text.append('\n');
                }
                text.append(wrapped);
            }
        }
        return text.toString();
    }

    /**
     * Cuts a line with colour codes into lines of at most {@code width} visible characters, at
     * spaces where it can and inside a word too long for a line. Each new line starts with the
     * colour in force where the cut fell.
     */
    static List<String> wrap(String line, int width) {
        List<String> lines = new ArrayList<String>();
        StringBuilder current = new StringBuilder();
        int visible = 0;
        String colour = "";
        String[] words = line.split(" ", -1);
        for (int w = 0; w < words.length; w++) {
            String word = words[w];
            int wordVisible = ChatColor.stripColor(word).length();
            if (visible > 0 && visible + 1 + wordVisible > width) {
                lines.add(current.toString());
                current = new StringBuilder(colour);
                visible = 0;
            } else if (w > 0) {
                current.append(' ');
                visible++;
            }
            for (int i = 0; i < word.length(); i++) {
                char c = word.charAt(i);
                if (c == ChatColor.COLOR_CHAR && i + 1 < word.length()) {
                    colour = word.substring(i, i + 2);
                    current.append(colour);
                    i++;
                    continue;
                }
                if (visible == width) {
                    lines.add(current.toString());
                    current = new StringBuilder(colour);
                    visible = 0;
                }
                current.append(c);
                visible++;
            }
        }
        lines.add(current.toString());
        return lines;
    }

    /**
     * The detail page of the plugin or failed jar named by a query, matched
     * case-insensitively and with spaces as underscores, like
     * PluginManager#getPlugin.
     */
    List<String> detailLines(String query) {
        String key = key(query);
        for (Entry plugin : plugins) {
            if (key(plugin.name).equals(key)) {
                return detailLines(plugin);
            }
        }
        for (LoadFailure failure : failures) {
            if ((failure.getPluginName() != null && key(failure.getPluginName()).equals(key))
                || key(failure.getFileName()).equals(key)) {
                return detailLines(failure);
            }
        }
        List<String> lines = new ArrayList<String>();
        lines.add(ChatColor.RED + "No plugin named '" + query + "'.");
        List<String> suggestions = new ArrayList<String>();
        for (String name : names()) {
            if (suggestions.size() < MAX_SUGGESTIONS && key(name).contains(key)) {
                suggestions.add(name);
            }
        }
        if (!suggestions.isEmpty()) {
            lines.add(ChatColor.GRAY + "Did you mean: " + ChatColor.WHITE + join(suggestions) + ChatColor.GRAY + "?");
        }
        return lines;
    }

    private List<String> detailLines(Entry plugin) {
        List<String> lines = new ArrayList<String>();
        lines.add(ChatColor.GOLD + "--- " + ChatColor.WHITE + ChatColor.BOLD + plugin.name + ChatColor.RESET
            + ChatColor.GRAY + " v" + plugin.version + " "
            + (plugin.enabled ? ChatColor.GREEN + "(enabled)" : ChatColor.RED + "(disabled)")
            + ChatColor.GOLD + " ---");
        if (!plugin.enabled && plugin.enableFailure != null) {
            lines.add(field("Enable error", ChatColor.RED + plugin.enableFailure));
        }
        if (plugin.description != null) {
            lines.add(field("Description", plugin.description));
        }
        if (!plugin.authors.isEmpty()) {
            lines.add(field(plugin.authors.size() == 1 ? "Author" : "Authors", join(plugin.authors)));
        }
        if (plugin.website != null) {
            lines.add(field("Website", plugin.website));
        }
        if (!plugin.depend.isEmpty()) {
            lines.add(field("Depends", dependencies(plugin.depend)));
        }
        if (!plugin.softDepend.isEmpty()) {
            lines.add(field("Soft depends", dependencies(plugin.softDepend)));
        }
        List<String> requiredBy = new ArrayList<String>();
        for (Entry other : plugins) {
            for (String dependency : other.depend) {
                if (key(dependency).equals(key(plugin.name))) {
                    requiredBy.add(other.name);
                    break;
                }
            }
        }
        if (!requiredBy.isEmpty()) {
            lines.add(field("Required by", join(requiredBy)));
        }
        if (!plugin.commands.isEmpty()) {
            List<String> commands = new ArrayList<String>(plugin.commands);
            Collections.sort(commands, String.CASE_INSENSITIVE_ORDER);
            StringBuilder shown = new StringBuilder();
            for (int i = 0; i < commands.size() && i < MAX_COMMANDS; i++) {
                if (i > 0) {
                    shown.append(", ");
                }
                shown.append('/').append(commands.get(i));
            }
            if (commands.size() > MAX_COMMANDS) {
                shown.append(ChatColor.GRAY).append(" and ").append(commands.size() - MAX_COMMANDS).append(" more");
            }
            lines.add(field("Commands (" + commands.size() + ")", shown.toString()));
        }
        return lines;
    }

    private List<String> detailLines(LoadFailure failure) {
        List<String> lines = new ArrayList<String>();
        lines.add(ChatColor.GOLD + "--- " + ChatColor.WHITE + ChatColor.BOLD + failure.getDisplayName() + ChatColor.RESET
            + " " + ChatColor.DARK_RED + "(failed to load)" + ChatColor.GOLD + " ---");
        lines.add(field("File", failure.getFileName()));
        lines.add(field("Reason", ChatColor.RED + failure.getReason()));
        return lines;
    }

    /**
     * The plugin and failed jar names starting with a prefix, any case.
     */
    List<String> complete(String prefix) {
        String key = key(prefix);
        List<String> matches = new ArrayList<String>();
        for (String name : names()) {
            if (key(name).startsWith(key)) {
                matches.add(name);
            }
        }
        Collections.sort(matches, String.CASE_INSENSITIVE_ORDER);
        return matches;
    }

    private Set<String> names() {
        Set<String> names = new LinkedHashSet<String>();
        for (Entry plugin : plugins) {
            names.add(plugin.name);
        }
        for (LoadFailure failure : failures) {
            names.add(failure.getDisplayName());
        }
        return names;
    }

    /**
     * Dependencies coloured by their state: green enabled, red disabled,
     * dark red with "(missing)" when no plugin of that name is loaded.
     */
    private String dependencies(List<String> names) {
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < names.size(); i++) {
            String name = names.get(i);
            if (i > 0) {
                text.append(ChatColor.WHITE).append(", ");
            }
            Entry dependency = find(name);
            if (dependency == null) {
                text.append(ChatColor.DARK_RED).append(name).append(" (missing)");
            } else {
                text.append(dependency.enabled ? ChatColor.GREEN : ChatColor.RED).append(name);
            }
        }
        return text.toString();
    }

    private Entry find(String name) {
        String key = key(name);
        for (Entry plugin : plugins) {
            if (key(plugin.name).equals(key)) {
                return plugin;
            }
        }
        return null;
    }

    private static TextComponent clickable(String name, net.md_5.bungee.api.ChatColor color, String hover, String alias) {
        TextComponent component = new TextComponent(name);
        component.setColor(color);
        component.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText(hover)));
        component.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/" + alias + " " + name));
        return component;
    }

    private static TextComponent separator() {
        TextComponent separator = new TextComponent(", ");
        separator.setColor(net.md_5.bungee.api.ChatColor.WHITE);
        return separator;
    }

    private static String field(String label, String value) {
        return ChatColor.GRAY + label + ": " + ChatColor.WHITE + value;
    }

    private static String join(List<String> values) {
        StringBuilder text = new StringBuilder();
        for (String value : values) {
            if (text.length() > 0) {
                text.append(", ");
            }
            text.append(value);
        }
        return text.toString();
    }

    private static String key(String name) {
        return name.replace(' ', '_').toLowerCase(Locale.ROOT);
    }

    /**
     * One loaded plugin, as /plugins shows it.
     */
    static final class Entry {
        final String name;
        final String version;
        final boolean enabled;
        final String description;
        final List<String> authors;
        final String website;
        final List<String> depend;
        final List<String> softDepend;
        final List<String> commands;
        final String enableFailure;

        Entry(String name, String version, boolean enabled, String description, List<String> authors, String website,
              List<String> depend, List<String> softDepend, Collection<String> commands, String enableFailure) {
            this.name = name;
            this.version = version;
            this.enabled = enabled;
            this.description = description;
            this.authors = immutable(authors);
            this.website = website;
            this.depend = immutable(depend);
            this.softDepend = immutable(softDepend);
            this.commands = immutable(commands);
            this.enableFailure = enableFailure;
        }

        static Entry of(Plugin plugin, PluginProblems problems) {
            PluginDescriptionFile description = plugin.getDescription();
            return new Entry(description.getName(), description.getVersion(), plugin.isEnabled(), description.getDescription(),
                description.getAuthors(), description.getWebsite(), description.getDepend(), description.getSoftDepend(),
                description.getCommands() == null ? null : description.getCommands().keySet(),
                problems == null ? null : problems.getEnableFailure(description.getName()));
        }

        private static List<String> immutable(Collection<String> values) {
            return values == null ? Collections.<String>emptyList() : Collections.unmodifiableList(new ArrayList<String>(values));
        }
    }
}
