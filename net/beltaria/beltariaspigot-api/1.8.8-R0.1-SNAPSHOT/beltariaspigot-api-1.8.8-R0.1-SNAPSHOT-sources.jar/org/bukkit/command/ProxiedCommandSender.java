
package org.bukkit.command;

public interface ProxiedCommandSender extends CommandSender, net.kyori.adventure.audience.ForwardingAudience.Single { // PandaSpigot - Adventure

    /**
     * Returns the CommandSender which triggered this proxied command
     *
     * @return the caller which triggered the command
     */
    CommandSender getCaller();

    /**
     * Returns the CommandSender which is being used to call the command
     *
     * @return the caller which the command is being run as
     */
    CommandSender getCallee();

    // PandaSpigot start - Adventure
    @Override
    default void sendMessage(net.kyori.adventure.text.Component message) { // BeltariaSpigot - Adventure 5: the Identity and MessageType overloads are gone
        net.kyori.adventure.audience.ForwardingAudience.Single.super.sendMessage(message);
    }

    // BeltariaSpigot start - Adventure 5: forwarded to the caller like the plain overload (CommandSender declares both)
    @Override
    default void sendMessage(net.kyori.adventure.text.Component message, net.kyori.adventure.chat.ChatType.Bound boundChatType) {
        net.kyori.adventure.audience.ForwardingAudience.Single.super.sendMessage(message, boundChatType);
    }

    @Override
    default void sendMessage(net.kyori.adventure.chat.SignedMessage signedMessage, net.kyori.adventure.chat.ChatType.Bound boundChatType) {
        net.kyori.adventure.audience.ForwardingAudience.Single.super.sendMessage(signedMessage, boundChatType);
    }
    // BeltariaSpigot end

    @Override
    default net.kyori.adventure.audience.Audience audience() {
        return this.getCaller();
    }
    // PandaSpigot end

}
