
package org.bukkit.command;

public interface ProxiedCommandSender extends CommandSender, net.kyori.adventure.audience.ForwardingAudience.Single { // PandaSpigot - Adventure

    /**
     * Returns the CommandSender which triggered this proxied command
     *
     * @return the caller which triggered the command
     */
    CommandSender getCaller();

    /**
     * Returns the CommandSender which is being used to call the command
     *
     * @return the caller which the command is being run as
     */
    CommandSender getCallee();

    // PandaSpigot start - Adventure
    @Override
    default void sendMessage(net.kyori.adventure.identity.Identity source, net.kyori.adventure.text.Component message, net.kyori.adventure.audience.MessageType type) {
        net.kyori.adventure.audience.ForwardingAudience.Single.super.sendMessage(source, message, type);
    }

    @Override
    default net.kyori.adventure.audience.Audience audience() {
        return this.getCaller();
    }
    // PandaSpigot end

}
