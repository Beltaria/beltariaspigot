package com.destroystokyo.paper.entity.ai;

/**
 * What a goal takes control of while it runs. Two running goals of one mob never share a type:
 * the mob's selector stops the lower-priority one.
 * <p>
 * {@link #TARGET} goals live in the mob's target selector and choose what it attacks; the others
 * live in its goal selector and decide what it does.
 */
public enum GoalType {

    /** The mob's movement. */
    MOVE,
    /** Where the mob looks. */
    LOOK,
    /** Whether the mob jumps. */
    JUMP,
    /** What the mob targets; such a goal runs in the target selector. */
    TARGET,
    /** Something the other types do not name; such a goal excludes nothing. */
    UNKNOWN_BEHAVIOR
}
