package com.destroystokyo.paper.entity;

import java.util.List;

import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;

/**
 * The navigator of a mob: where it walks, and along which path.
 * <p>
 * Speed is a multiplier of the mob's {@link org.bukkit.attribute.Attribute#GENERIC_MOVEMENT_SPEED}:
 * 1 walks, a zombie chases at 1 too, a panicking animal runs at 2.
 * <p>
 * <strong>A path may arrive a tick or two after it was asked for.</strong> With asynchronous
 * pathfinding on ({@code asyncPathfinding.enabled}), {@link #moveTo} hands the search to a worker
 * and answers {@code true} as soon as it was accepted; the mob starts walking when the path lands.
 * {@link #hasPath()} answers {@code false} while a search is in flight. A goal that needs the
 * answer at once should ask {@link #findPath} instead, which always searches on the spot.
 */
public interface Pathfinder {

    /**
     * Gets the mob this navigator belongs to.
     *
     * @return the mob
     */
    Mob getEntity();

    /** Stops the current path, and any search still in flight. */
    void stopPathfinding();

    /**
     * Gets whether the mob currently has a path to walk along.
     *
     * @return {@code true} if a path is set
     */
    boolean hasPath();

    /**
     * Gets the path the mob walks along.
     *
     * @return the current path, or {@code null}
     */
    PathResult getCurrentPath();

    /**
     * Searches a path to a location, without walking it. Always synchronous.
     *
     * @param loc the destination
     * @return the path found, possibly stopping short, or {@code null} if none was found
     */
    PathResult findPath(Location loc);

    /**
     * Searches a path to an entity, without walking it. Always synchronous.
     *
     * @param target the entity to reach
     * @return the path found, possibly stopping short, or {@code null} if none was found
     */
    PathResult findPath(LivingEntity target);

    /**
     * Walks to a location at speed 1.
     *
     * @param loc the destination
     * @return {@code true} if a path was found, or a search was accepted
     */
    default boolean moveTo(Location loc) {
        return this.moveTo(loc, 1.0D);
    }

    /**
     * Walks to a location.
     *
     * @param loc the destination
     * @param speed the speed multiplier
     * @return {@code true} if a path was found, or a search was accepted
     */
    boolean moveTo(Location loc, double speed);

    /**
     * Walks to an entity at speed 1.
     *
     * @param target the entity to reach
     * @return {@code true} if a path was found, or a search was accepted
     */
    default boolean moveTo(LivingEntity target) {
        return this.moveTo(target, 1.0D);
    }

    /**
     * Walks to an entity.
     *
     * @param target the entity to reach
     * @param speed the speed multiplier
     * @return {@code true} if a path was found, or a search was accepted
     */
    boolean moveTo(LivingEntity target, double speed);

    /**
     * Walks along a path found earlier, at speed 1.
     *
     * @param path the path
     * @return {@code true} if the path was accepted
     */
    default boolean moveTo(PathResult path) {
        return this.moveTo(path, 1.0D);
    }

    /**
     * Walks along a path found earlier.
     *
     * @param path the path
     * @param speed the speed multiplier
     * @return {@code true} if the path was accepted
     */
    boolean moveTo(PathResult path, double speed);

    /**
     * Gets whether the mob paths through doors it can open. Ground mobs only.
     *
     * @return {@code true} if doors are walkable to it
     */
    boolean canOpenDoors();

    /**
     * Sets whether the mob paths through doors it can open. Ground mobs only.
     *
     * @param canOpenDoors {@code true} to path through doors
     */
    void setCanOpenDoors(boolean canOpenDoors);

    /**
     * Gets whether the mob paths through doors it will break, as zombies do. Ground mobs only.
     *
     * @return {@code true} if it breaks doors on its way
     */
    boolean canBreakDoors();

    /**
     * Sets whether the mob paths through doors it will break. Ground mobs only.
     *
     * @param canBreakDoors {@code true} to break doors on its way
     */
    void setCanBreakDoors(boolean canBreakDoors);

    /**
     * Gets whether the mob paths through water, swimming. Ground mobs only.
     *
     * @return {@code true} if water is walkable to it
     */
    boolean canFloat();

    /**
     * Sets whether the mob paths through water. Ground mobs only.
     *
     * @param canFloat {@code true} to path through water
     */
    void setCanFloat(boolean canFloat);

    /**
     * Gets whether the mob avoids water when it could go around, as villagers do. Ground mobs
     * only.
     *
     * @return {@code true} if it avoids water
     */
    boolean avoidsWater();

    /**
     * Sets whether the mob avoids water when it could go around. Ground mobs only.
     *
     * @param avoidsWater {@code true} to avoid water
     */
    void setAvoidsWater(boolean avoidsWater);

    /** A path: the points a mob walks through, and where it is along them. */
    interface PathResult {

        /**
         * Gets every point of the path, from the mob's start to the path's end.
         *
         * @return the points, a copy
         */
        List<Location> getPoints();

        /**
         * Gets the index of the point the mob walks to next.
         *
         * @return the index in {@link #getPoints()}
         */
        int getNextPointIndex();

        /**
         * Gets the point the mob walks to next.
         *
         * @return the next point, or {@code null} once the path is walked
         */
        Location getNextPoint();

        /**
         * Gets the last point of the path.
         *
         * @return the final point, or {@code null} for an empty path
         */
        Location getFinalPoint();

        /**
         * Gets whether the path ends where it was asked to. The search returns the closest it
         * could get, so a path to a target behind a wall ends at the wall.
         *
         * @return {@code true} if the final point is the destination asked for
         */
        boolean canReachFinalPoint();
    }
}
