package com.destroystokyo.paper.entity.ai;

import java.util.EnumSet;

import org.bukkit.entity.Mob;

/**
 * A behaviour a mob can run, written by a plugin and given to {@link MobGoals}.
 * <p>
 * The mob's selector asks {@link #shouldActivate()} while the goal is idle and
 * {@link #shouldStayActive()} every tick while it runs; between {@link #start()} and
 * {@link #stop()} it calls {@link #tick()} once per tick. A goal only starts when no running goal
 * of higher priority holds one of its {@link #getTypes() types}, and a running goal is stopped
 * when a higher-priority one that shares a type wants to start. All of it happens on the main
 * thread.
 * <p>
 * Two things about this server to design around. With distance-tiered throttling on
 * ({@code dab.enabled}), a mob far from every player is asked {@link #shouldActivate()} only
 * every few ticks: a condition that is true for a single tick can be missed. And a mob with its
 * AI disabled, a nerfed spawner mob, or a world with {@code mobAi.disable} runs no goal at all.
 *
 * @param <T> the mob type this goal applies to
 */
public interface Goal<T extends Mob> {

    /**
     * Asked while the goal is idle: should it start now?
     *
     * @return {@code true} to start the goal this tick
     */
    boolean shouldActivate();

    /**
     * Asked every tick while the goal runs: should it keep running? The default says no, so a
     * goal that does something over several ticks must override it.
     *
     * @return {@code true} to keep the goal running
     */
    default boolean shouldStayActive() {
        return false;
    }

    /** Called once when the goal starts. */
    default void start() {
    }

    /** Called once when the goal stops, whether it chose to or was interrupted. */
    default void stop() {
    }

    /** Called every tick while the goal runs, after the selector's own bookkeeping. */
    default void tick() {
    }

    /**
     * Gets the key identifying this kind of goal.
     *
     * @return the goal's key
     */
    GoalKey<T> getKey();

    /**
     * Gets what this goal takes control of. A goal with {@link GoalType#TARGET} is placed in the
     * mob's target selector; any other goal in its goal selector. An empty set excludes nothing.
     *
     * @return the types, never {@code null}
     */
    EnumSet<GoalType> getTypes();
}
