package com.destroystokyo.paper.entity.ai;

import org.bukkit.NamespacedKey;
import org.bukkit.entity.Mob;

/**
 * The keys of the game's own goals, one per {@code PathfinderGoal} class of Minecraft 1.8.8.
 * <p>
 * A vanilla goal taken from {@link MobGoals#getAllGoals} carries one of these keys and can be
 * removed by it, or added back to another mob of a type that accepts it. A goal class the
 * server does not know - one a plugin wrote against the internals - is keyed
 * {@code minecraft:unknown_<class name>}.
 *
 * @param <T> the mob type the goal applies to
 */
public interface VanillaGoal<T extends Mob> extends Goal<T> {

    GoalKey<Mob> ARROW_ATTACK = GoalKey.of(Mob.class, NamespacedKey.minecraft("arrow_attack"));
    GoalKey<Mob> AVOID_TARGET = GoalKey.of(Mob.class, NamespacedKey.minecraft("avoid_target"));
    GoalKey<Mob> BEG = GoalKey.of(Mob.class, NamespacedKey.minecraft("beg"));
    GoalKey<Mob> BREAK_DOOR = GoalKey.of(Mob.class, NamespacedKey.minecraft("break_door"));
    GoalKey<Mob> BREED = GoalKey.of(Mob.class, NamespacedKey.minecraft("breed"));
    GoalKey<Mob> DEFEND_VILLAGE = GoalKey.of(Mob.class, NamespacedKey.minecraft("defend_village"));
    GoalKey<Mob> DOOR_INTERACT = GoalKey.of(Mob.class, NamespacedKey.minecraft("door_interact"));
    GoalKey<Mob> EAT_TILE = GoalKey.of(Mob.class, NamespacedKey.minecraft("eat_tile"));
    GoalKey<Mob> FLEE_SUN = GoalKey.of(Mob.class, NamespacedKey.minecraft("flee_sun"));
    GoalKey<Mob> FLOAT = GoalKey.of(Mob.class, NamespacedKey.minecraft("float"));
    GoalKey<Mob> FOLLOW_OWNER = GoalKey.of(Mob.class, NamespacedKey.minecraft("follow_owner"));
    GoalKey<Mob> FOLLOW_PARENT = GoalKey.of(Mob.class, NamespacedKey.minecraft("follow_parent"));
    GoalKey<Mob> GOTO_TARGET = GoalKey.of(Mob.class, NamespacedKey.minecraft("goto_target"));
    GoalKey<Mob> HURT_BY_TARGET = GoalKey.of(Mob.class, NamespacedKey.minecraft("hurt_by_target"));
    GoalKey<Mob> INTERACT = GoalKey.of(Mob.class, NamespacedKey.minecraft("interact"));
    GoalKey<Mob> INTERACT_VILLAGERS = GoalKey.of(Mob.class, NamespacedKey.minecraft("interact_villagers"));
    GoalKey<Mob> JUMP_ON_BLOCK = GoalKey.of(Mob.class, NamespacedKey.minecraft("jump_on_block"));
    GoalKey<Mob> LEAP_AT_TARGET = GoalKey.of(Mob.class, NamespacedKey.minecraft("leap_at_target"));
    GoalKey<Mob> LOOK_AT_PLAYER = GoalKey.of(Mob.class, NamespacedKey.minecraft("look_at_player"));
    GoalKey<Mob> LOOK_AT_TRADING_PLAYER = GoalKey.of(Mob.class, NamespacedKey.minecraft("look_at_trading_player"));
    GoalKey<Mob> MAKE_LOVE = GoalKey.of(Mob.class, NamespacedKey.minecraft("make_love"));
    GoalKey<Mob> MELEE_ATTACK = GoalKey.of(Mob.class, NamespacedKey.minecraft("melee_attack"));
    GoalKey<Mob> MOVE_INDOORS = GoalKey.of(Mob.class, NamespacedKey.minecraft("move_indoors"));
    GoalKey<Mob> MOVE_THROUGH_VILLAGE = GoalKey.of(Mob.class, NamespacedKey.minecraft("move_through_village"));
    GoalKey<Mob> MOVE_TOWARDS_RESTRICTION = GoalKey.of(Mob.class, NamespacedKey.minecraft("move_towards_restriction"));
    GoalKey<Mob> MOVE_TOWARDS_TARGET = GoalKey.of(Mob.class, NamespacedKey.minecraft("move_towards_target"));
    GoalKey<Mob> NEAREST_ATTACKABLE_TARGET = GoalKey.of(Mob.class, NamespacedKey.minecraft("nearest_attackable_target"));
    GoalKey<Mob> NEAREST_ATTACKABLE_TARGET_INSENTIENT = GoalKey.of(Mob.class, NamespacedKey.minecraft("nearest_attackable_target_insentient"));
    GoalKey<Mob> OCELOT_ATTACK = GoalKey.of(Mob.class, NamespacedKey.minecraft("ocelot_attack"));
    GoalKey<Mob> OFFER_FLOWER = GoalKey.of(Mob.class, NamespacedKey.minecraft("offer_flower"));
    GoalKey<Mob> OPEN_DOOR = GoalKey.of(Mob.class, NamespacedKey.minecraft("open_door"));
    GoalKey<Mob> OWNER_HURT_BY_TARGET = GoalKey.of(Mob.class, NamespacedKey.minecraft("owner_hurt_by_target"));
    GoalKey<Mob> OWNER_HURT_TARGET = GoalKey.of(Mob.class, NamespacedKey.minecraft("owner_hurt_target"));
    GoalKey<Mob> PANIC = GoalKey.of(Mob.class, NamespacedKey.minecraft("panic"));
    GoalKey<Mob> PASSENGER_CARROT_STICK = GoalKey.of(Mob.class, NamespacedKey.minecraft("passenger_carrot_stick"));
    GoalKey<Mob> PLAY = GoalKey.of(Mob.class, NamespacedKey.minecraft("play"));
    GoalKey<Mob> RANDOM_LOOKAROUND = GoalKey.of(Mob.class, NamespacedKey.minecraft("random_lookaround"));
    GoalKey<Mob> RANDOM_STROLL = GoalKey.of(Mob.class, NamespacedKey.minecraft("random_stroll"));
    GoalKey<Mob> RANDOM_TARGET_NON_TAMED = GoalKey.of(Mob.class, NamespacedKey.minecraft("random_target_non_tamed"));
    GoalKey<Mob> RESTRICT_OPEN_DOOR = GoalKey.of(Mob.class, NamespacedKey.minecraft("restrict_open_door"));
    GoalKey<Mob> RESTRICT_SUN = GoalKey.of(Mob.class, NamespacedKey.minecraft("restrict_sun"));
    GoalKey<Mob> SIT = GoalKey.of(Mob.class, NamespacedKey.minecraft("sit"));
    GoalKey<Mob> SWELL = GoalKey.of(Mob.class, NamespacedKey.minecraft("swell"));
    GoalKey<Mob> TAKE_FLOWER = GoalKey.of(Mob.class, NamespacedKey.minecraft("take_flower"));
    GoalKey<Mob> TAME = GoalKey.of(Mob.class, NamespacedKey.minecraft("tame"));
    GoalKey<Mob> TARGET = GoalKey.of(Mob.class, NamespacedKey.minecraft("target"));
    GoalKey<Mob> TARGET_NEAREST_PLAYER = GoalKey.of(Mob.class, NamespacedKey.minecraft("target_nearest_player"));
    GoalKey<Mob> TEMPT = GoalKey.of(Mob.class, NamespacedKey.minecraft("tempt"));
    GoalKey<Mob> TRADE_WITH_PLAYER = GoalKey.of(Mob.class, NamespacedKey.minecraft("trade_with_player"));
    GoalKey<Mob> VILLAGER_FARM = GoalKey.of(Mob.class, NamespacedKey.minecraft("villager_farm"));
}
