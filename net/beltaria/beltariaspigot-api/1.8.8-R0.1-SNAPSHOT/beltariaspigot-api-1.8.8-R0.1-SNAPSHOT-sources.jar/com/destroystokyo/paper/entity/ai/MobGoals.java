package com.destroystokyo.paper.entity.ai;

import java.util.Collection;

import org.bukkit.entity.Mob;

/**
 * The goals of every mob on the server: what it does, in what order, and what it targets.
 * <p>
 * Obtained from {@link org.bukkit.Bukkit#getMobGoals()}. A goal is added with a priority - lower
 * runs first - and either a plugin's own {@link Goal} or a vanilla one taken back from
 * {@link #getAllGoals} after it was removed. Vanilla goals are recognised by their
 * {@link VanillaGoal} keys, so a plugin can strip a zombie of its attack and keep its wandering.
 * Main thread only.
 */
public interface MobGoals {

    /**
     * Adds a goal to a mob, in the selector its types call for.
     *
     * @param mob the mob
     * @param priority the priority; lower runs first, vanilla uses 0 to 8
     * @param goal the goal
     * @param <T> the mob type
     */
    <T extends Mob> void addGoal(T mob, int priority, Goal<? super T> goal);

    /**
     * Removes a goal from a mob, stopping it if it runs.
     *
     * @param mob the mob
     * @param goal the goal, as it was added or as {@link #getAllGoals} returned it
     * @param <T> the mob type
     */
    <T extends Mob> void removeGoal(T mob, Goal<? super T> goal);

    /**
     * Removes every goal of a mob, vanilla ones included. What is left is a mob that stands still
     * and looks at nothing.
     *
     * @param mob the mob
     * @param <T> the mob type
     */
    <T extends Mob> void removeAllGoals(T mob);

    /**
     * Removes every goal of a mob that has a type.
     *
     * @param mob the mob
     * @param type the type
     * @param <T> the mob type
     */
    <T extends Mob> void removeAllGoals(T mob, GoalType type);

    /**
     * Removes every goal of a mob with a key.
     *
     * @param mob the mob
     * @param key the key
     * @param <T> the mob type
     */
    <T extends Mob> void removeGoal(T mob, GoalKey<? super T> key);

    /**
     * Gets whether a mob has at least one goal with a key.
     *
     * @param mob the mob
     * @param key the key
     * @param <T> the mob type
     * @return {@code true} if one is registered, running or not
     */
    <T extends Mob> boolean hasGoal(T mob, GoalKey<? super T> key);

    /**
     * Gets the first goal of a mob with a key.
     *
     * @param mob the mob
     * @param key the key
     * @param <T> the mob type
     * @return the goal, or {@code null}
     */
    <T extends Mob> Goal<T> getGoal(T mob, GoalKey<? super T> key);

    /**
     * Gets every goal of a mob with a key.
     *
     * @param mob the mob
     * @param key the key
     * @param <T> the mob type
     * @return the goals, a copy
     */
    <T extends Mob> Collection<Goal<T>> getGoals(T mob, GoalKey<? super T> key);

    /**
     * Gets every goal of a mob, in both selectors, running or not.
     *
     * @param mob the mob
     * @param <T> the mob type
     * @return the goals, a copy
     */
    <T extends Mob> Collection<Goal<T>> getAllGoals(T mob);

    /**
     * Gets every goal of a mob that has a type.
     *
     * @param mob the mob
     * @param type the type
     * @param <T> the mob type
     * @return the goals, a copy
     */
    <T extends Mob> Collection<Goal<T>> getAllGoals(T mob, GoalType type);

    /**
     * Gets every goal of a mob that does not have a type.
     *
     * @param mob the mob
     * @param type the type
     * @param <T> the mob type
     * @return the goals, a copy
     */
    <T extends Mob> Collection<Goal<T>> getAllGoalsWithout(T mob, GoalType type);

    /**
     * Gets every goal of a mob that runs right now.
     *
     * @param mob the mob
     * @param <T> the mob type
     * @return the goals, a copy
     */
    <T extends Mob> Collection<Goal<T>> getRunningGoals(T mob);

    /**
     * Gets every running goal of a mob that has a type.
     *
     * @param mob the mob
     * @param type the type
     * @param <T> the mob type
     * @return the goals, a copy
     */
    <T extends Mob> Collection<Goal<T>> getRunningGoals(T mob, GoalType type);

    /**
     * Gets every running goal of a mob that does not have a type.
     *
     * @param mob the mob
     * @param type the type
     * @param <T> the mob type
     * @return the goals, a copy
     */
    <T extends Mob> Collection<Goal<T>> getRunningGoalsWithout(T mob, GoalType type);
}
