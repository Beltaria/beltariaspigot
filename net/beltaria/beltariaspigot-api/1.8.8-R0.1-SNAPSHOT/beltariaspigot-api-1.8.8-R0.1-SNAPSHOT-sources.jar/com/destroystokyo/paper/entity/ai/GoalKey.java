package com.destroystokyo.paper.entity.ai;

import org.apache.commons.lang.Validate;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Mob;

/**
 * Identifies a kind of goal: a namespaced name, and the narrowest mob type it applies to.
 * <p>
 * Vanilla goals are keyed under the {@code minecraft} namespace by {@link VanillaGoal}; a plugin
 * keys its own under its own.
 *
 * @param <T> the mob type the goal applies to
 */
public final class GoalKey<T extends Mob> {

    private final Class<T> entityClass;
    private final NamespacedKey namespacedKey;

    private GoalKey(Class<T> entityClass, NamespacedKey namespacedKey) {
        this.entityClass = entityClass;
        this.namespacedKey = namespacedKey;
    }

    public static <A extends Mob> GoalKey<A> of(Class<A> entityClass, NamespacedKey namespacedKey) {
        Validate.notNull(entityClass, "entityClass");
        Validate.notNull(namespacedKey, "namespacedKey");
        return new GoalKey<A>(entityClass, namespacedKey);
    }

    public Class<T> getEntityClass() {
        return this.entityClass;
    }

    public NamespacedKey getNamespacedKey() {
        return this.namespacedKey;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof GoalKey)) {
            return false;
        }
        GoalKey<?> that = (GoalKey<?>) other;
        return this.entityClass.equals(that.entityClass)
                && this.namespacedKey.equals(that.namespacedKey);
    }

    @Override
    public int hashCode() {
        return 31 * this.entityClass.hashCode() + this.namespacedKey.hashCode();
    }

    @Override
    public String toString() {
        return "GoalKey{entityClass=" + this.entityClass.getName() + ", namespacedKey="
                + this.namespacedKey + "}";
    }
}
